//
//  ViewController.m
//  12
//
//  Created by  张靖 on 16/6/2.
//  Copyright © 2016年 yifangdigital. All rights reserved.
//

#import "ViewController.h"
#import "shareManager.h"
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *label;

@end

@implementation ViewController
static int number = 1;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)btn1:(id)sender {
    shareManager *usernum = [shareManager sharenum];
    usernum.num = ++number;
    NSLog(@"%ld",(long)usernum.num);
}
- (IBAction)btn2:(id)sender {
    shareManager *usernum = [shareManager sharenum];
    usernum.num = ++number;
    NSLog(@"%ld",(long)usernum.num);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
