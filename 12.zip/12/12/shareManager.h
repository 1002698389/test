//
//  shareManager.h
//  12
//
//  Created by  张靖 on 16/6/2.
//  Copyright © 2016年 yifangdigital. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface shareManager : NSObject
@property(nonatomic,assign)NSInteger num;
+(shareManager*)sharenum;
@end
