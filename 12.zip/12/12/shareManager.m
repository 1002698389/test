//
//  shareManager.m
//  12
//
//  Created by  张靖 on 16/6/2.
//  Copyright © 2016年 yifangdigital. All rights reserved.
//

#import "shareManager.h"
static shareManager *_number = nil;
@implementation shareManager
+(shareManager*)sharenum
{
    if (_number == nil ) {
        _number = [[shareManager alloc]init];
    }
    return _number;
}
@end
